/**
 * Bunneis Fan Club — Social Features + Games
 * Image Gallery with Albums, Group Creation, Chat (Group + DM), Mini-Games
 * All data persisted in localStorage.
 */
(function () {
  /* ===== Data Store (localStorage) ===== */
  const STORE_KEYS = { albums: 'bunneis_albums', groups: 'bunneis_groups', chats: 'bunneis_chats', members: 'bunneis_members', scores: 'bunneis_scores' };

  function getStore(key) { return JSON.parse(localStorage.getItem(key) || '[]'); }
  function setStore(key, data) { localStorage.setItem(key, JSON.stringify(data)); }

  function getUser() {
    const u = JSON.parse(localStorage.getItem('bunneis_user') || 'null');
    return u || { name: 'Guest', email: 'guest@bunneis.com', picture: 'https://ui-avatars.com/api/?name=Guest&background=8896AB&color=fff&size=128' };
  }

  // Seed demo members
  function seedMembers() {
    let members = getStore(STORE_KEYS.members);
    if (members.length === 0) {
      members = [
        { id: 'm1', name: 'Minji Fan', picture: 'https://ui-avatars.com/api/?name=Minji+Fan&background=1B3A8C&color=fff&size=128', status: 'online' },
        { id: 'm2', name: 'Hanni Love', picture: 'https://ui-avatars.com/api/?name=Hanni+Love&background=4A90D9&color=fff&size=128', status: 'online' },
        { id: 'm3', name: 'Danielle Star', picture: 'https://ui-avatars.com/api/?name=Danielle+Star&background=6BB3F0&color=fff&size=128', status: 'offline' },
        { id: 'm4', name: 'Haerin Cat', picture: 'https://ui-avatars.com/api/?name=Haerin+Cat&background=0F2259&color=fff&size=128', status: 'online' },
        { id: 'm5', name: 'Hyein Young', picture: 'https://ui-avatars.com/api/?name=Hyein+Young&background=1B3A8C&color=fff&size=128', status: 'offline' },
      ];
      setStore(STORE_KEYS.members, members);
    }
    return members;
  }

  function seedAlbums() {
    let albums = getStore(STORE_KEYS.albums);
    if (albums.length === 0) {
      albums = [
        { id: 'a1', name: 'Concert Memories 🎤', createdBy: 'Minji Fan', date: '2026-03-15', images: [
          { id: 'img1', src: 'images/album-1.png', caption: 'คอนเสิร์ตที่ไม่มีวันลืม 💙', likes: 24, comments: [] },
          { id: 'img2', src: 'images/album-2.png', caption: 'ตอนเปิด Ditto! 🎵', likes: 38, comments: [] },
        ]},
        { id: 'a2', name: 'Photocard Collection 📸', createdBy: 'Hanni Love', date: '2026-03-20', images: [
          { id: 'img3', src: 'images/product-3.png', caption: 'โฟโต้การ์ดที่สะสมมา 🐰', likes: 15, comments: [] },
          { id: 'img4', src: 'images/product-1.png', caption: 'เซ็ตใหม่ที่ได้มา!', likes: 42, comments: [] },
        ]},
        { id: 'a3', name: 'Album Unboxing 📦', createdBy: 'Danielle Star', date: '2026-03-25', images: [
          { id: 'img5', src: 'images/album-3.png', caption: 'Unboxing How Sweet! 🍬', likes: 56, comments: [] },
          { id: 'img6', src: 'images/product-2.png', caption: 'Vinyl สวยมาก!', likes: 31, comments: [] },
        ]},
      ];
      setStore(STORE_KEYS.albums, albums);
    }
    return albums;
  }

  function seedGroups() {
    let groups = getStore(STORE_KEYS.groups);
    if (groups.length === 0) {
      groups = [
        { id: 'g1', name: 'Bunnies Thailand 🇹🇭', desc: 'กลุ่มแฟนคลับ NewJeans ไทย', members: ['m1','m2','m3','m4','m5'], picture: 'https://ui-avatars.com/api/?name=BT&background=1B3A8C&color=fff&size=128', messages: [
          { from: 'Minji Fan', text: 'สวัสดีค่า ยินดีต้อนรับทุกคน! 🐰', time: '14:30', pic: 'https://ui-avatars.com/api/?name=Minji+Fan&background=1B3A8C&color=fff&size=128' },
          { from: 'Hanni Love', text: 'อัลบั้มใหม่มาแล้ว ใครพรีออเดอร์แล้วบ้าง?', time: '14:32', pic: 'https://ui-avatars.com/api/?name=Hanni+Love&background=4A90D9&color=fff&size=128' },
          { from: 'Haerin Cat', text: 'พรีออเดอร์แล้วค่ะ เอาครบทุกเวอร์ชัน! 😻', time: '14:35', pic: 'https://ui-avatars.com/api/?name=Haerin+Cat&background=0F2259&color=fff&size=128' },
        ]},
        { id: 'g2', name: 'Album Traders 💿', desc: 'แลกเปลี่ยนอัลบั้ม โฟโต้การ์ด', members: ['m1','m3','m5'], picture: 'https://ui-avatars.com/api/?name=AT&background=4A90D9&color=fff&size=128', messages: [
          { from: 'Danielle Star', text: 'มีใครอยากแลก Haerin PC ไหม?', time: '10:15', pic: 'https://ui-avatars.com/api/?name=Danielle+Star&background=6BB3F0&color=fff&size=128' },
        ]},
      ];
      setStore(STORE_KEYS.groups, groups);
    }
    return groups;
  }

  /* ===== Tab System ===== */
  let activeTab = 'gallery';

  function initTabs() {
    const tabBtns = document.querySelectorAll('.fc-tab-btn');
    tabBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        // Do nothing if this tab is already active (prevents "closing" on mobile)
        if (btn.classList.contains('active')) return;
        tabBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeTab = btn.dataset.tab;
        renderTab();
        // Scroll active tab into view on mobile
        btn.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
      });
    });
  }

  function renderTab() {
    const content = document.getElementById('fc-tab-content');
    if (!content) return;
    switch (activeTab) {
      case 'gallery': renderGallery(content); break;
      case 'groups': renderGroups(content); break;
      case 'chat': renderChat(content); break;
      case 'games': renderGames(content); break;
    }
  }

  /* ================================================================
     GALLERY TAB — Albums, Folders, Image Upload (FIXED), Lightbox
     ================================================================ */
  let currentAlbumId = null;
  // In-memory store for uploaded images (avoids localStorage quota issues)
  const uploadedImages = {};

  function renderGallery(container) {
    if (currentAlbumId) {
      renderAlbumView(container);
    } else {
      renderAlbumList(container);
    }
  }

  function renderAlbumList(container) {
    const albums = getStore(STORE_KEYS.albums);
    container.innerHTML = `
      <div class="fc-toolbar">
        <h3 class="fc-toolbar-title">📸 อัลบั้มรูปภาพ</h3>
        <button class="btn btn-primary btn-sm" id="btn-create-album">+ สร้างอัลบั้มใหม่</button>
      </div>
      <div class="fc-album-grid">
        ${albums.map(a => {
          const coverSrc = a.images.length > 0 ? (uploadedImages[a.images[0].id] || a.images[0].src) : '';
          return `
          <div class="fc-album-card" data-album="${a.id}">
            <div class="fc-album-cover">
              ${coverSrc
                ? `<img src="${coverSrc}" alt="${a.name}">`
                : `<div class="fc-album-empty">📁</div>`}
              <div class="fc-album-count">${a.images.length} รูป</div>
            </div>
            <div class="fc-album-meta">
              <h4 class="fc-album-name">${a.name}</h4>
              <p class="fc-album-by">โดย ${a.createdBy} • ${a.date}</p>
            </div>
          </div>`;
        }).join('')}
      </div>
    `;
    document.getElementById('btn-create-album')?.addEventListener('click', showCreateAlbumModal);
    container.querySelectorAll('.fc-album-card').forEach(card => {
      card.addEventListener('click', () => { currentAlbumId = card.dataset.album; renderTab(); });
    });
  }

  function renderAlbumView(container) {
    const albums = getStore(STORE_KEYS.albums);
    const album = albums.find(a => a.id === currentAlbumId);
    if (!album) { currentAlbumId = null; renderTab(); return; }
    container.innerHTML = `
      <div class="fc-toolbar">
        <button class="fc-back-btn" id="btn-back-albums">← กลับ</button>
        <h3 class="fc-toolbar-title">${album.name}</h3>
        <div class="fc-upload-area">
          <button class="btn btn-primary btn-sm" id="btn-upload-img">📷 อัปโหลดรูป</button>
          <input type="file" id="file-upload" accept="image/*" multiple style="display:none">
        </div>
      </div>
      <div id="upload-status" class="fc-upload-status" style="display:none;"></div>
      <div class="fc-image-grid">
        ${album.images.map(img => {
          const imgSrc = uploadedImages[img.id] || img.src;
          return `
          <div class="fc-image-card" data-img="${img.id}">
            <img src="${imgSrc}" alt="${img.caption}" loading="lazy">
            <div class="fc-image-overlay">
              <span class="fc-image-likes">❤️ ${img.likes}</span>
              <p class="fc-image-caption">${img.caption}</p>
            </div>
          </div>`;
        }).join('')}
        ${album.images.length === 0 ? '<p class="fc-empty">ยังไม่มีรูปภาพ — อัปโหลดรูปแรกของคุณ!</p>' : ''}
      </div>
    `;
    document.getElementById('btn-back-albums').addEventListener('click', () => { currentAlbumId = null; renderTab(); });
    const uploadBtn = document.getElementById('btn-upload-img');
    const fileInput = document.getElementById('file-upload');
    uploadBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', handleImageUpload);
    container.querySelectorAll('.fc-image-card').forEach(card => {
      card.addEventListener('click', () => showLightbox(album, card.dataset.img));
    });
  }

  /**
   * FIXED image upload — uses canvas to compress images before storing.
   * Also uses Object URLs for display to avoid hitting localStorage limits.
   */
  function handleImageUpload(e) {
    const files = Array.from(e.target.files);
    if (!files.length) return;

    const statusEl = document.getElementById('upload-status');
    if (statusEl) {
      statusEl.style.display = 'flex';
      statusEl.innerHTML = `<span class="fc-upload-spinner"></span> กำลังอัปโหลด ${files.length} รูป...`;
    }

    const albums = getStore(STORE_KEYS.albums);
    const album = albums.find(a => a.id === currentAlbumId);
    if (!album) return;

    let processed = 0;
    const total = files.length;

    files.forEach((file, index) => {
      // Create an object URL for immediate display (no size limit)
      const objectUrl = URL.createObjectURL(file);
      const imgId = 'img_' + Date.now() + '_' + index;

      // Store object URL in memory for display
      uploadedImages[imgId] = objectUrl;

      // Compress via canvas for localStorage backup (thumbnail)
      compressImage(file, 400, 0.7).then(thumbnail => {
        album.images.push({
          id: imgId,
          src: thumbnail,  // compressed thumbnail for localStorage
          caption: file.name.replace(/\.[^.]+$/, ''),
          likes: 0,
          comments: []
        });
        processed++;
        if (statusEl) {
          statusEl.innerHTML = `<span class="fc-upload-spinner"></span> อัปโหลดแล้ว ${processed}/${total} รูป...`;
        }
        if (processed === total) {
          try {
            setStore(STORE_KEYS.albums, albums);
          } catch (err) {
            console.warn('localStorage quota exceeded, images stored in memory only');
          }
          if (statusEl) {
            statusEl.innerHTML = `✅ อัปโหลดสำเร็จ ${total} รูป!`;
            setTimeout(() => { statusEl.style.display = 'none'; }, 2000);
          }
          renderTab();
        }
      });
    });

    // Reset file input so same file can be re-selected
    e.target.value = '';
  }

  /**
   * Compress an image file using canvas.
   * @param {File} file - The image file
   * @param {number} maxDim - Max width/height in pixels
   * @param {number} quality - JPEG quality (0-1)
   * @returns {Promise<string>} - Base64 data URL (compressed)
   */
  function compressImage(file, maxDim, quality) {
    return new Promise((resolve) => {
      const img = new Image();
      const url = URL.createObjectURL(file);
      img.onload = () => {
        let w = img.width, h = img.height;
        if (w > maxDim || h > maxDim) {
          if (w > h) { h = Math.round(h * maxDim / w); w = maxDim; }
          else { w = Math.round(w * maxDim / h); h = maxDim; }
        }
        const canvas = document.createElement('canvas');
        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => {
        URL.revokeObjectURL(url);
        // Fallback: just use the file directly
        const reader = new FileReader();
        reader.onload = (ev) => resolve(ev.target.result);
        reader.readAsDataURL(file);
      };
      img.src = url;
    });
  }

  function showCreateAlbumModal() {
    const modal = createModal(`
      <div class="auth-modal-header">
        <div class="auth-modal-logo">📁</div>
        <h2 class="auth-modal-title">สร้างอัลบั้มใหม่</h2>
        <p class="auth-modal-subtitle">สร้างโฟลเดอร์เก็บรูปภาพของคุณ — ไม่จำกัดจำนวนรูปและขนาดไฟล์</p>
      </div>
      <div class="auth-modal-body">
        <input type="text" class="form-input" id="album-name-input" placeholder="ชื่ออัลบั้ม เช่น Concert Memories 🎤">
        <button class="btn btn-primary" id="btn-save-album" style="width:100%">📸 สร้างอัลบั้ม</button>
      </div>
    `);
    document.getElementById('btn-save-album').addEventListener('click', () => {
      const name = document.getElementById('album-name-input').value.trim();
      if (!name) return;
      const albums = getStore(STORE_KEYS.albums);
      const user = getUser();
      albums.push({ id: 'a_' + Date.now(), name, createdBy: user.name, date: new Date().toISOString().slice(0, 10), images: [] });
      setStore(STORE_KEYS.albums, albums);
      closeModalEl(modal);
      renderTab();
    });
  }

  function showLightbox(album, imgId) {
    // Re-fetch album from store to get latest data
    const albums = getStore(STORE_KEYS.albums);
    const freshAlbum = albums.find(a => a.id === album.id) || album;
    const img = freshAlbum.images.find(i => i.id === imgId);
    if (!img) return;
    const idx = freshAlbum.images.indexOf(img);
    const imgSrc = uploadedImages[img.id] || img.src;
    const modal = createModal(`
      <div class="fc-lightbox">
        <div class="fc-lightbox-img">
          <img src="${imgSrc}" alt="${img.caption}" id="lightbox-img">
        </div>
        <div class="fc-lightbox-info">
          <div class="fc-lightbox-actions">
            <button class="fc-like-btn" id="btn-like">❤️ ${img.likes}</button>
            <span class="fc-img-index">${idx + 1} / ${freshAlbum.images.length}</span>
          </div>
          <p class="fc-lightbox-caption">${img.caption}</p>
          <div class="fc-lightbox-nav">
            ${idx > 0 ? '<button class="btn btn-outline btn-sm" id="lb-prev">← ก่อนหน้า</button>' : '<span></span>'}
            ${idx < freshAlbum.images.length - 1 ? '<button class="btn btn-outline btn-sm" id="lb-next">ถัดไป →</button>' : '<span></span>'}
          </div>
        </div>
      </div>
    `, 'fc-lightbox-modal');
    document.getElementById('btn-like')?.addEventListener('click', () => {
      img.likes++;
      const al2 = getStore(STORE_KEYS.albums);
      const a = al2.find(al => al.id === freshAlbum.id);
      if (a) { const i = a.images.find(im => im.id === imgId); if (i) i.likes = img.likes; setStore(STORE_KEYS.albums, al2); }
      document.getElementById('btn-like').textContent = `❤️ ${img.likes}`;
    });
    document.getElementById('lb-prev')?.addEventListener('click', () => { closeModalEl(modal); showLightbox(freshAlbum, freshAlbum.images[idx - 1].id); });
    document.getElementById('lb-next')?.addEventListener('click', () => { closeModalEl(modal); showLightbox(freshAlbum, freshAlbum.images[idx + 1].id); });
  }

  /* ================================================================
     GROUPS TAB
     ================================================================ */
  function renderGroups(container) {
    const groups = getStore(STORE_KEYS.groups);
    const members = getStore(STORE_KEYS.members);
    container.innerHTML = `
      <div class="fc-toolbar">
        <h3 class="fc-toolbar-title">👥 กลุ่ม Bunnies</h3>
        <button class="btn btn-primary btn-sm" id="btn-create-group">+ สร้างกลุ่มใหม่</button>
      </div>
      <div class="fc-group-list">
        ${groups.map(g => `
          <div class="fc-group-card" data-group="${g.id}">
            <img src="${g.picture}" alt="${g.name}" class="fc-group-avatar">
            <div class="fc-group-info">
              <h4 class="fc-group-name">${g.name}</h4>
              <p class="fc-group-desc">${g.desc}</p>
              <span class="fc-group-members">👥 ${g.members.length} สมาชิก • 💬 ${g.messages.length} ข้อความ</span>
            </div>
            <button class="btn btn-outline btn-sm fc-group-enter" data-gid="${g.id}">เข้าร่วม →</button>
          </div>
        `).join('')}
      </div>
      <div class="fc-toolbar" style="margin-top: var(--sp-2xl);">
        <h3 class="fc-toolbar-title">🐰 สมาชิกออนไลน์</h3>
      </div>
      <div class="fc-members-list">
        ${members.map(m => `
          <div class="fc-member-item">
            <div class="fc-member-avatar-wrap">
              <img src="${m.picture}" alt="${m.name}" class="fc-member-avatar">
              <span class="fc-member-status ${m.status}"></span>
            </div>
            <span class="fc-member-name">${m.name}</span>
            <button class="btn btn-outline btn-sm fc-dm-btn" data-mid="${m.id}" data-mname="${m.name}" data-mpic="${m.picture}">💬 แชท</button>
          </div>
        `).join('')}
      </div>
    `;
    document.getElementById('btn-create-group')?.addEventListener('click', showCreateGroupModal);
    container.querySelectorAll('.fc-group-enter').forEach(btn => {
      btn.addEventListener('click', (e) => { e.stopPropagation(); openGroupChat(btn.dataset.gid); });
    });
    container.querySelectorAll('.fc-dm-btn').forEach(btn => {
      btn.addEventListener('click', () => openDmChat(btn.dataset.mid, btn.dataset.mname, btn.dataset.mpic));
    });
  }

  function showCreateGroupModal() {
    const members = getStore(STORE_KEYS.members);
    const modal = createModal(`
      <div class="auth-modal-header">
        <div class="auth-modal-logo">👥</div>
        <h2 class="auth-modal-title">สร้างกลุ่ม Bunnies</h2>
        <p class="auth-modal-subtitle">สร้างกลุ่มแชทเพื่อพูดคุยกับแฟนคลับ</p>
      </div>
      <div class="auth-modal-body">
        <input type="text" class="form-input" id="group-name-input" placeholder="ชื่อกลุ่ม">
        <input type="text" class="form-input" id="group-desc-input" placeholder="คำอธิบายกลุ่ม">
        <div class="fc-checkbox-list">
          <p style="font-weight:600; margin-bottom: 0.5rem;">เลือกสมาชิก:</p>
          ${members.map(m => `
            <label class="fc-checkbox">
              <input type="checkbox" value="${m.id}" checked> ${m.name}
            </label>
          `).join('')}
        </div>
        <button class="btn btn-primary" id="btn-save-group" style="width:100%">👥 สร้างกลุ่ม</button>
      </div>
    `);
    document.getElementById('btn-save-group').addEventListener('click', () => {
      const name = document.getElementById('group-name-input').value.trim();
      const desc = document.getElementById('group-desc-input').value.trim();
      if (!name) return;
      const checked = Array.from(modal.querySelectorAll('.fc-checkbox input:checked')).map(c => c.value);
      const groups = getStore(STORE_KEYS.groups);
      const initials = name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
      groups.push({
        id: 'g_' + Date.now(), name, desc: desc || 'กลุ่มแฟนคลับ Bunneis',
        members: checked, messages: [],
        picture: `https://ui-avatars.com/api/?name=${initials}&background=1B3A8C&color=fff&size=128`
      });
      setStore(STORE_KEYS.groups, groups);
      closeModalEl(modal);
      renderTab();
    });
  }

  /* ================================================================
     CHAT TAB — Group Chat + DM (Instagram-like)
     ================================================================ */
  let activeChatId = null;
  let activeChatType = null;

  function renderChat(container) {
    if (activeChatId) { renderChatRoom(container); }
    else { renderChatList(container); }
  }

  function renderChatList(container) {
    const groups = getStore(STORE_KEYS.groups);
    const members = getStore(STORE_KEYS.members);
    container.innerHTML = `
      <div class="fc-toolbar"><h3 class="fc-toolbar-title">💬 แชท</h3></div>
      <div class="fc-chat-section-title">กลุ่ม</div>
      <div class="fc-chat-list">
        ${groups.map(g => {
          const lastMsg = g.messages.length > 0 ? g.messages[g.messages.length - 1] : null;
          return `
          <div class="fc-chat-item" data-ctype="group" data-cid="${g.id}">
            <img src="${g.picture}" alt="${g.name}" class="fc-chat-avatar">
            <div class="fc-chat-preview">
              <h4>${g.name}</h4>
              <p>${lastMsg ? lastMsg.from + ': ' + lastMsg.text.slice(0, 40) : 'ยังไม่มีข้อความ'}</p>
            </div>
            ${lastMsg ? `<span class="fc-chat-time">${lastMsg.time}</span>` : ''}
          </div>`;
        }).join('')}
      </div>
      <div class="fc-chat-section-title">ข้อความส่วนตัว</div>
      <div class="fc-chat-list">
        ${members.map(m => `
          <div class="fc-chat-item" data-ctype="dm" data-cid="${m.id}" data-cname="${m.name}" data-cpic="${m.picture}">
            <div class="fc-member-avatar-wrap">
              <img src="${m.picture}" alt="${m.name}" class="fc-chat-avatar">
              <span class="fc-member-status ${m.status}"></span>
            </div>
            <div class="fc-chat-preview">
              <h4>${m.name}</h4>
              <p>${m.status === 'online' ? '🟢 ออนไลน์' : '⚫ ออฟไลน์'}</p>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    container.querySelectorAll('.fc-chat-item').forEach(item => {
      item.addEventListener('click', () => {
        if (item.dataset.ctype === 'group') openGroupChat(item.dataset.cid);
        else openDmChat(item.dataset.cid, item.dataset.cname, item.dataset.cpic);
      });
    });
  }

  function openGroupChat(groupId) {
    activeChatId = groupId; activeChatType = 'group'; activeTab = 'chat';
    document.querySelectorAll('.fc-tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === 'chat'));
    renderTab();
  }

  function openDmChat(memberId, memberName, memberPic) {
    activeChatId = memberId; activeChatType = 'dm'; activeTab = 'chat';
    window._dmMeta = { name: memberName, pic: memberPic };
    document.querySelectorAll('.fc-tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === 'chat'));
    renderTab();
  }

  function renderChatRoom(container) {
    let title, messages, pic;
    if (activeChatType === 'group') {
      const groups = getStore(STORE_KEYS.groups);
      const group = groups.find(g => g.id === activeChatId);
      if (!group) { activeChatId = null; renderTab(); return; }
      title = group.name; messages = group.messages; pic = group.picture;
    } else {
      title = window._dmMeta?.name || 'DM'; pic = window._dmMeta?.pic || '';
      const chats = getStore(STORE_KEYS.chats);
      const dm = chats.find(c => c.id === activeChatId);
      messages = dm ? dm.messages : [];
    }
    const user = getUser();
    container.innerHTML = `
      <div class="fc-chat-header">
        <button class="fc-back-btn" id="btn-back-chat">←</button>
        <img src="${pic}" alt="${title}" class="fc-chat-header-avatar">
        <div><h4 class="fc-chat-header-name">${title}</h4>
        <span class="fc-chat-header-status">${activeChatType === 'group' ? 'กลุ่ม' : '🟢 ออนไลน์'}</span></div>
      </div>
      <div class="fc-chat-messages" id="chat-messages">
        ${messages.map(m => `
          <div class="fc-msg ${m.from === user.name ? 'fc-msg-me' : ''}">
            ${m.from !== user.name ? `<img src="${m.pic}" class="fc-msg-avatar" alt="${m.from}">` : ''}
            <div class="fc-msg-bubble">
              ${m.from !== user.name ? `<span class="fc-msg-from">${m.from}</span>` : ''}
              <p>${m.text}</p><span class="fc-msg-time">${m.time}</span>
            </div>
          </div>
        `).join('')}
        ${messages.length === 0 ? '<p class="fc-empty" style="padding:2rem">👋 เริ่มบทสนทนาแรกเลย!</p>' : ''}
      </div>
      <div class="fc-chat-input-bar">
        <input type="text" class="fc-chat-input" id="chat-input" placeholder="พิมพ์ข้อความ..." autocomplete="off">
        <button class="fc-send-btn" id="btn-send">➤</button>
      </div>
    `;
    const msgContainer = document.getElementById('chat-messages');
    msgContainer.scrollTop = msgContainer.scrollHeight;
    document.getElementById('btn-back-chat').addEventListener('click', () => { activeChatId = null; renderTab(); });
    document.getElementById('btn-send').addEventListener('click', sendMessage);
    document.getElementById('chat-input').addEventListener('keydown', (e) => { if (e.key === 'Enter') sendMessage(); });
  }

  function sendMessage() {
    const input = document.getElementById('chat-input');
    const text = input.value.trim();
    if (!text) return;
    const user = getUser();
    const now = new Date();
    const time = now.getHours().toString().padStart(2, '0') + ':' + now.getMinutes().toString().padStart(2, '0');
    const msg = { from: user.name, text, time, pic: user.picture };
    if (activeChatType === 'group') {
      const groups = getStore(STORE_KEYS.groups);
      const group = groups.find(g => g.id === activeChatId);
      if (group) { group.messages.push(msg); setStore(STORE_KEYS.groups, groups); }
    } else {
      const chats = getStore(STORE_KEYS.chats);
      let dm = chats.find(c => c.id === activeChatId);
      if (!dm) { dm = { id: activeChatId, messages: [] }; chats.push(dm); }
      dm.messages.push(msg); setStore(STORE_KEYS.chats, chats);
    }
    input.value = '';
    renderTab();
    if (activeChatType === 'dm') {
      setTimeout(() => {
        const replies = ['สวัสดีค่า! 🐰', 'อัลบั้มใหม่สวยมากเลย!', 'ไว้คุยกันนะ 💙', 'เห็นด้วยเลย! ✨', 'NewJeans is the best! 🎵'];
        const reply = replies[Math.floor(Math.random() * replies.length)];
        const chats = getStore(STORE_KEYS.chats);
        let dm = chats.find(c => c.id === activeChatId);
        if (dm) {
          const n2 = new Date();
          dm.messages.push({ from: window._dmMeta?.name || 'User', text: reply, time: n2.getHours().toString().padStart(2, '0') + ':' + n2.getMinutes().toString().padStart(2, '0'), pic: window._dmMeta?.pic || '' });
          setStore(STORE_KEYS.chats, chats); renderTab();
        }
      }, 1200);
    }
  }

  /* ================================================================
     GAMES TAB — Mini-Games for Bunnies
     ================================================================ */
  let activeGame = null;

  function renderGames(container) {
    if (activeGame) { renderGamePlay(container); return; }
    const scores = getStore(STORE_KEYS.scores);
    container.innerHTML = `
      <div class="fc-toolbar">
        <h3 class="fc-toolbar-title">🎮 เกม Bunnies</h3>
      </div>
      <div class="fc-games-grid">
        <div class="fc-game-card" data-game="memory">
          <div class="fc-game-icon">🃏</div>
          <h4 class="fc-game-name">Memory Match</h4>
          <p class="fc-game-desc">จับคู่การ์ด NewJeans — ฝึกความจำ!</p>
          <span class="fc-game-best">${getHighScore('memory', scores)}</span>
        </div>
        <div class="fc-game-card" data-game="quiz">
          <div class="fc-game-icon">❓</div>
          <h4 class="fc-game-name">Bunnies Quiz</h4>
          <p class="fc-game-desc">ทดสอบความรู้เกี่ยวกับ NewJeans!</p>
          <span class="fc-game-best">${getHighScore('quiz', scores)}</span>
        </div>
        <div class="fc-game-card" data-game="catch">
          <div class="fc-game-icon">🐰</div>
          <h4 class="fc-game-name">Catch the Bunny</h4>
          <p class="fc-game-desc">จับกระต่ายให้ได้มากที่สุดใน 30 วินาที!</p>
          <span class="fc-game-best">${getHighScore('catch', scores)}</span>
        </div>
        <div class="fc-game-card" data-game="word">
          <div class="fc-game-icon">🔤</div>
          <h4 class="fc-game-name">Word Scramble</h4>
          <p class="fc-game-desc">เรียงตัวอักษรให้เป็นชื่อเพลง NewJeans!</p>
          <span class="fc-game-best">${getHighScore('word', scores)}</span>
        </div>
      </div>
      <div class="fc-toolbar" style="margin-top: var(--sp-2xl);">
        <h3 class="fc-toolbar-title">🏆 อันดับคะแนน</h3>
      </div>
      <div class="fc-leaderboard">
        ${generateLeaderboard(scores)}
      </div>
    `;
    container.querySelectorAll('.fc-game-card').forEach(card => {
      card.addEventListener('click', () => { activeGame = card.dataset.game; renderTab(); });
    });
  }

  function getHighScore(game, scores) {
    const s = scores.filter(s => s.game === game);
    if (s.length === 0) return '🏆 —';
    return '🏆 ' + Math.max(...s.map(x => x.score));
  }

  function generateLeaderboard(scores) {
    if (scores.length === 0) return '<p class="fc-empty">ยังไม่มีคะแนน — เล่นเกมเพื่อทำคะแนน!</p>';
    const sorted = [...scores].sort((a, b) => b.score - a.score).slice(0, 10);
    return sorted.map((s, i) => `
      <div class="fc-leader-row">
        <span class="fc-leader-rank">${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : '#' + (i + 1)}</span>
        <span class="fc-leader-name">${s.player}</span>
        <span class="fc-leader-game">${s.game}</span>
        <span class="fc-leader-score">${s.score} คะแนน</span>
      </div>
    `).join('');
  }

  function saveScore(game, score) {
    const user = getUser();
    const scores = getStore(STORE_KEYS.scores);
    scores.push({ game, score, player: user.name, date: new Date().toISOString().slice(0, 10) });
    setStore(STORE_KEYS.scores, scores);
  }

  function renderGamePlay(container) {
    switch (activeGame) {
      case 'memory': renderMemoryGame(container); break;
      case 'quiz': renderQuizGame(container); break;
      case 'catch': renderCatchGame(container); break;
      case 'word': renderWordGame(container); break;
      default: activeGame = null; renderTab();
    }
  }

  /* ----------- GAME 1: Memory Match ----------- */
  function renderMemoryGame(container) {
    const emojis = ['🐰', '💙', '🎵', '📀', '🌟', '🎤', '💿', '🦋'];
    const cards = [...emojis, ...emojis].sort(() => Math.random() - 0.5);
    let flipped = [], matched = [], moves = 0, canFlip = true;

    container.innerHTML = `
      <div class="fc-toolbar">
        <button class="fc-back-btn" id="btn-back-game">← กลับ</button>
        <h3 class="fc-toolbar-title">🃏 Memory Match</h3>
        <span class="fc-game-stat" id="game-moves">จำนวนครั้ง: 0</span>
      </div>
      <div class="fc-memory-grid" id="memory-grid">
        ${cards.map((emoji, i) => `
          <div class="fc-memory-card" data-idx="${i}" data-emoji="${emoji}">
            <div class="fc-memory-inner">
              <div class="fc-memory-front">🐰</div>
              <div class="fc-memory-back">${emoji}</div>
            </div>
          </div>
        `).join('')}
      </div>
    `;
    document.getElementById('btn-back-game').addEventListener('click', () => { activeGame = null; renderTab(); });
    container.querySelectorAll('.fc-memory-card').forEach(card => {
      card.addEventListener('click', () => {
        if (!canFlip) return;
        const idx = parseInt(card.dataset.idx);
        if (flipped.includes(idx) || matched.includes(idx)) return;
        card.classList.add('flipped');
        flipped.push(idx);
        if (flipped.length === 2) {
          moves++;
          document.getElementById('game-moves').textContent = `จำนวนครั้ง: ${moves}`;
          canFlip = false;
          const [a, b] = flipped;
          const cardA = container.querySelector(`.fc-memory-card[data-idx="${a}"]`);
          const cardB = container.querySelector(`.fc-memory-card[data-idx="${b}"]`);
          if (cardA.dataset.emoji === cardB.dataset.emoji) {
            matched.push(a, b);
            flipped = [];
            canFlip = true;
            cardA.classList.add('matched');
            cardB.classList.add('matched');
            if (matched.length === cards.length) {
              const score = Math.max(100 - (moves - 8) * 5, 10);
              saveScore('memory', score);
              setTimeout(() => showGameResult('Memory Match', score, `${moves} ครั้ง`), 500);
            }
          } else {
            setTimeout(() => {
              cardA.classList.remove('flipped');
              cardB.classList.remove('flipped');
              flipped = [];
              canFlip = true;
            }, 800);
          }
        }
      });
    });
  }

  /* ----------- GAME 2: Bunnies Quiz ----------- */
  function renderQuizGame(container) {
    const questions = [
      { q: 'NewJeans เดบิวท์ปีอะไร?', opts: ['2021', '2022', '2023', '2024'], ans: 1 },
      { q: 'สมาชิก NewJeans มีกี่คน?', opts: ['4', '5', '6', '7'], ans: 1 },
      { q: 'เพลงแรกของ NewJeans คือเพลงอะไร?', opts: ['Hype Boy', 'Attention', 'Ditto', 'OMG'], ans: 1 },
      { q: 'แฟนคลับ NewJeans เรียกว่าอะไร?', opts: ['ARMY', 'Bunnies', 'BLINK', 'Once'], ans: 1 },
      { q: 'สมาชิกที่อายุน้อยที่สุดคือใคร?', opts: ['Minji', 'Hanni', 'Danielle', 'Hyein'], ans: 3 },
      { q: 'NewJeans สังกัดค่ายอะไร?', opts: ['SM', 'YG', 'JYP', 'ADOR'], ans: 3 },
      { q: 'เพลง "Super Shy" ออกในปีอะไร?', opts: ['2022', '2023', '2024', '2025'], ans: 1 },
      { q: 'อัลบั้ม "Get Up" เป็นอัลบั้มประเภทใด?', opts: ['Full Album', 'Mini Album', 'Single', 'EP'], ans: 3 },
    ];
    let current = 0, score = 0;
    const shuffled = questions.sort(() => Math.random() - 0.5).slice(0, 5);

    function showQuestion() {
      const q = shuffled[current];
      container.innerHTML = `
        <div class="fc-toolbar">
          <button class="fc-back-btn" id="btn-back-game">← กลับ</button>
          <h3 class="fc-toolbar-title">❓ Bunnies Quiz</h3>
          <span class="fc-game-stat">ข้อ ${current + 1}/${shuffled.length}</span>
        </div>
        <div class="fc-quiz-card">
          <div class="fc-quiz-progress">
            <div class="fc-quiz-progress-bar" style="width: ${(current / shuffled.length) * 100}%"></div>
          </div>
          <h3 class="fc-quiz-question">${q.q}</h3>
          <div class="fc-quiz-opts">
            ${q.opts.map((opt, i) => `<button class="fc-quiz-opt" data-opt="${i}">${opt}</button>`).join('')}
          </div>
          <p class="fc-quiz-score">คะแนน: ${score}/${current}</p>
        </div>
      `;
      document.getElementById('btn-back-game').addEventListener('click', () => { activeGame = null; renderTab(); });
      container.querySelectorAll('.fc-quiz-opt').forEach(btn => {
        btn.addEventListener('click', () => {
          const chosen = parseInt(btn.dataset.opt);
          if (chosen === q.ans) { score++; btn.classList.add('correct'); }
          else {
            btn.classList.add('wrong');
            container.querySelector(`.fc-quiz-opt[data-opt="${q.ans}"]`).classList.add('correct');
          }
          container.querySelectorAll('.fc-quiz-opt').forEach(b => b.style.pointerEvents = 'none');
          setTimeout(() => {
            current++;
            if (current < shuffled.length) showQuestion();
            else {
              const finalScore = Math.round((score / shuffled.length) * 100);
              saveScore('quiz', finalScore);
              showGameResult('Bunnies Quiz', finalScore, `${score}/${shuffled.length} ถูกต้อง`);
            }
          }, 1200);
        });
      });
    }
    showQuestion();
  }

  /* ----------- GAME 3: Catch the Bunny ----------- */
  function renderCatchGame(container) {
    let score = 0, timeLeft = 30, timerId = null;
    container.innerHTML = `
      <div class="fc-toolbar">
        <button class="fc-back-btn" id="btn-back-game">← กลับ</button>
        <h3 class="fc-toolbar-title">🐰 Catch the Bunny</h3>
        <span class="fc-game-stat" id="catch-timer">⏱️ 30s</span>
      </div>
      <div class="fc-catch-area" id="catch-area">
        <div class="fc-catch-score" id="catch-score">คะแนน: 0</div>
        <div class="fc-catch-start" id="catch-start">
          <button class="btn btn-primary" id="btn-start-catch">🐰 เริ่มเกม!</button>
        </div>
      </div>
    `;
    document.getElementById('btn-back-game').addEventListener('click', () => {
      if (timerId) clearInterval(timerId);
      activeGame = null; renderTab();
    });
    document.getElementById('btn-start-catch').addEventListener('click', () => {
      const area = document.getElementById('catch-area');
      document.getElementById('catch-start').style.display = 'none';
      timerId = setInterval(() => {
        timeLeft--;
        document.getElementById('catch-timer').textContent = `⏱️ ${timeLeft}s`;
        if (timeLeft <= 0) {
          clearInterval(timerId);
          saveScore('catch', score);
          showGameResult('Catch the Bunny', score, `จับได้ ${score} ตัว`);
        }
      }, 1000);
      spawnBunny(area);
    });

    function spawnBunny(area) {
      const existing = area.querySelectorAll('.fc-bunny');
      existing.forEach(b => b.remove());
      const bunny = document.createElement('div');
      bunny.className = 'fc-bunny';
      const bunnies = ['🐰', '🐇', '🦊', '🐱'];
      const isBunny = Math.random() > 0.25;
      bunny.textContent = isBunny ? bunnies[Math.floor(Math.random() * 2)] : bunnies[2 + Math.floor(Math.random() * 2)];
      bunny.dataset.isBunny = isBunny;
      const maxX = area.clientWidth - 60;
      const maxY = area.clientHeight - 100;
      bunny.style.left = Math.max(10, Math.random() * maxX) + 'px';
      bunny.style.top = Math.max(60, Math.random() * maxY) + 'px';
      area.appendChild(bunny);
      bunny.addEventListener('click', () => {
        if (bunny.dataset.isBunny === 'true') {
          score++;
          bunny.textContent = '✨';
        } else {
          score = Math.max(0, score - 1);
          bunny.textContent = '❌';
        }
        document.getElementById('catch-score').textContent = `คะแนน: ${score}`;
        setTimeout(() => {
          if (timeLeft > 0) spawnBunny(area);
        }, 300);
      });
      // Auto-vanish after 1.5s
      setTimeout(() => {
        if (bunny.parentNode && timeLeft > 0) {
          bunny.remove();
          spawnBunny(area);
        }
      }, 1500);
    }
  }

  /* ----------- GAME 4: Word Scramble ----------- */
  function renderWordGame(container) {
    const words = [
      { word: 'ATTENTION', hint: '🎵 เพลงแรกที่ทำให้ทุกคนรู้จัก' },
      { word: 'HYPEBOY', hint: '🎵 เพลงฮิตจากอัลบั้มแรก' },
      { word: 'DITTO', hint: '🎵 เพลงที่ครองชาร์ตนานที่สุด' },
      { word: 'SUPERSHY', hint: '🎵 เพลงจาก Get Up' },
      { word: 'COOKIE', hint: '🎵 เพลงจาก New Jeans EP' },
      { word: 'NEWJEANS', hint: '🎤 ชื่อวง' },
      { word: 'BUNNIES', hint: '🐰 ชื่อแฟนคลับ' },
      { word: 'MINJI', hint: '👑 ลีดเดอร์ของวง' },
      { word: 'HANNI', hint: '🇻🇳 สมาชิกจากออสเตรเลีย' },
      { word: 'DANIELLE', hint: '🇦🇺 สมาชิกลูกครึ่ง' },
    ];
    let current = 0, score = 0;
    const picked = words.sort(() => Math.random() - 0.5).slice(0, 5);

    function showWord() {
      const w = picked[current];
      const scrambled = w.word.split('').sort(() => Math.random() - 0.5).join('');
      container.innerHTML = `
        <div class="fc-toolbar">
          <button class="fc-back-btn" id="btn-back-game">← กลับ</button>
          <h3 class="fc-toolbar-title">🔤 Word Scramble</h3>
          <span class="fc-game-stat">ข้อ ${current + 1}/${picked.length}</span>
        </div>
        <div class="fc-word-card">
          <div class="fc-word-scrambled">${scrambled.split('').map(c => `<span class="fc-word-letter">${c}</span>`).join('')}</div>
          <p class="fc-word-hint">${w.hint}</p>
          <div class="fc-word-input-row">
            <input type="text" class="form-input fc-word-input" id="word-input" placeholder="พิมพ์คำตอบ..." autocomplete="off" maxlength="${w.word.length}">
            <button class="btn btn-primary" id="btn-check-word">ตรวจ</button>
          </div>
          <p class="fc-word-feedback" id="word-feedback"></p>
          <p class="fc-quiz-score">คะแนน: ${score}/${current}</p>
        </div>
      `;
      document.getElementById('btn-back-game').addEventListener('click', () => { activeGame = null; renderTab(); });
      const input = document.getElementById('word-input');
      const checkBtn = document.getElementById('btn-check-word');
      const feedback = document.getElementById('word-feedback');
      const doCheck = () => {
        const ans = input.value.trim().toUpperCase();
        if (ans === w.word) {
          score++;
          feedback.textContent = '✅ ถูกต้อง!';
          feedback.style.color = '#22c55e';
        } else {
          feedback.textContent = `❌ คำตอบคือ: ${w.word}`;
          feedback.style.color = '#ef4444';
        }
        checkBtn.disabled = true;
        input.disabled = true;
        setTimeout(() => {
          current++;
          if (current < picked.length) showWord();
          else {
            const finalScore = Math.round((score / picked.length) * 100);
            saveScore('word', finalScore);
            showGameResult('Word Scramble', finalScore, `${score}/${picked.length} ถูกต้อง`);
          }
        }, 1500);
      };
      checkBtn.addEventListener('click', doCheck);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') doCheck(); });
      input.focus();
    }
    showWord();
  }

  /* ----------- Game Result Modal ----------- */
  function showGameResult(gameName, score, detail) {
    const emoji = score >= 80 ? '🏆' : score >= 50 ? '⭐' : '💪';
    const msg = score >= 80 ? 'ยอดเยี่ยม!' : score >= 50 ? 'ทำได้ดี!' : 'ลองอีกครั้งนะ!';
    const modal = createModal(`
      <div class="auth-modal-header">
        <div class="auth-modal-logo" style="font-size:2.5rem">${emoji}</div>
        <h2 class="auth-modal-title">${msg}</h2>
        <p class="auth-modal-subtitle">${gameName}</p>
      </div>
      <div class="fc-game-result">
        <div class="fc-game-result-score">${score}</div>
        <p class="fc-game-result-label">คะแนน</p>
        <p class="fc-game-result-detail">${detail}</p>
        <div class="fc-game-result-actions">
          <button class="btn btn-primary" id="btn-play-again">🔄 เล่นอีกครั้ง</button>
          <button class="btn btn-outline" id="btn-back-games">← กลับไปเมนูเกม</button>
        </div>
      </div>
    `);
    document.getElementById('btn-play-again').addEventListener('click', () => { closeModalEl(modal); renderTab(); });
    document.getElementById('btn-back-games').addEventListener('click', () => { closeModalEl(modal); activeGame = null; renderTab(); });
  }

  /* ===== Modal Utility ===== */
  function createModal(content, extraClass) {
    const overlay = document.createElement('div');
    overlay.className = 'auth-modal-overlay' + (extraClass ? ' ' + extraClass : '');
    overlay.innerHTML = `<div class="auth-modal"><button class="auth-modal-close" id="modal-close-dyn">&times;</button>${content}</div>`;
    document.body.appendChild(overlay);
    requestAnimationFrame(() => overlay.classList.add('show'));
    overlay.querySelector('#modal-close-dyn').addEventListener('click', () => closeModalEl(overlay));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModalEl(overlay); });
    return overlay;
  }
  function closeModalEl(el) { el.classList.remove('show'); setTimeout(() => el.remove(), 300); }

  /* ===== Init ===== */
  function init() {
    const content = document.getElementById('fc-tab-content');
    if (!content) return;
    seedMembers();
    seedAlbums();
    seedGroups();
    initTabs();
    renderTab();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    setTimeout(init, 50);
  }
})();
