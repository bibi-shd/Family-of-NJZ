/**
 * Bunneis — Component Loader
 * Loads header.html & footer.html into placeholders, sets active nav link.
 */
(function () {
  const parts = [
    { id: 'header-placeholder', file: 'components/header.html' },
    { id: 'footer-placeholder', file: 'components/footer.html' }
  ];

  function getPage() {
    const path = location.pathname.split('/').pop().replace('.html', '') || 'index';
    return path;
  }

  function setActive() {
    const page = getPage();
    document.querySelectorAll('.nav-link').forEach(link => {
      link.classList.toggle('active', link.dataset.page === page);
    });
  }

  function initMobileMenu() {
    const toggle = document.getElementById('mobile-toggle');
    const nav = document.getElementById('nav-list');
    if (!toggle || !nav) return;

    // Backdrop overlay
    const backdrop = document.createElement('div');
    backdrop.id = 'nav-backdrop';
    backdrop.style.cssText = [
      'position:fixed','inset:0','z-index:998',
      'background:rgba(0,0,0,0.4)','backdrop-filter:blur(2px)',
      'opacity:0','pointer-events:none',
      'transition:opacity 0.35s ease'
    ].join(';');
    document.body.appendChild(backdrop);

    function openMenu() {
      toggle.classList.add('active');
      nav.classList.add('open');
      backdrop.style.opacity = '1';
      backdrop.style.pointerEvents = 'auto';
      document.body.style.overflow = 'hidden';
    }

    function closeMenu() {
      toggle.classList.remove('active');
      nav.classList.remove('open');
      backdrop.style.opacity = '0';
      backdrop.style.pointerEvents = 'none';
      document.body.style.overflow = '';
    }

    toggle.addEventListener('click', () => {
      nav.classList.contains('open') ? closeMenu() : openMenu();
    });
    backdrop.addEventListener('click', closeMenu);
    nav.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', closeMenu);
    });
    const closeBtn = document.getElementById('nav-close-btn');
    if (closeBtn) closeBtn.addEventListener('click', closeMenu);
    document.addEventListener('keydown', e => {
      if (e.key === 'Escape' && nav.classList.contains('open')) closeMenu();
    });
  }

  function initHeaderScroll() {
    const header = document.getElementById('main-header');
    if (!header) return;
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 50);
    }, { passive: true });
  }

  async function load(part) {
    const el = document.getElementById(part.id);
    if (!el) return;
    try {
      const res = await fetch(part.file);
      if (!res.ok) throw new Error(res.status);
      el.innerHTML = await res.text();
    } catch (e) {
      console.warn(`Failed to load ${part.file}:`, e);
    }
  }

  async function init() {
    await Promise.all(parts.map(load));
    setActive();
    initMobileMenu();
    initHeaderScroll();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
